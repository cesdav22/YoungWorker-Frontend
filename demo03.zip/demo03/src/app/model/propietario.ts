export class Propietario{
    idPropietario: number=0;
    namePropietario: string="";
    emailPropietario: string="";
}