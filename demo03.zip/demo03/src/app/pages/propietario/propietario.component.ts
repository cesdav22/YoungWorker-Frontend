import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PropietarioService } from 'src/app/service/propietario.service';

@Component({
  selector: 'app-propietario',
  templateUrl: './propietario.component.html',
  styleUrls: ['./propietario.component.css']
})
export class PropietarioComponent implements OnInit {
  
  constructor(public route: ActivatedRoute) { }

  ngOnInit(): void {
  }
 
}
